# Advanced Git: Forking Workflow Sample Project

This is the sample project for the Forking Workflow chapter of the [RayWenderlich Advanced Git](https://store.raywenderlich.com/products/advanced-git) book.
