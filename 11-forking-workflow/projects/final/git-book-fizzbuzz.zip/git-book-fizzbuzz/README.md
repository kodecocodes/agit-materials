# Mastering Git: Forking Workflow Sample Project

This is the sample project for the Forking Workflow chapter of the [RayWenderlich Mastering Git](https://store.raywenderlich.com/products/mastering-git) book.
